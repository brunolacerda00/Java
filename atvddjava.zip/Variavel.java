public class Variavel{
    public static void main(String[] args){
    
    String nome="Bruno";
    int idade=18;
    double altura=1.76;
        /*
    System.out.println(nome);
    System.out.println(idade);
    System.out.println(altura);*/
    System.out.println("olá: "+nome+"sua idade é: "+idade+" e sua altura é: "+altura);
    }
}