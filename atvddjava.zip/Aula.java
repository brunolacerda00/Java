public class Aula{

    public static void main(String[] args){
        System.out.println("Hello word!"); 
          System.out.print("Hello word!");  
    }
}