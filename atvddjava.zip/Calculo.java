public class Calculo {
    
    public static void main(String[] args){
        double a=6;
        double b=5;
        double soma=a+b, sub=a-b, mult=a*b, div=a/b;

        System.out.println("Soma: "+soma);
        System.out.println("Subtração: "+sub);
        System.out.println("Multiplicação: "+mult);
        System.out.println("Divisão: "+div);
    }
}
